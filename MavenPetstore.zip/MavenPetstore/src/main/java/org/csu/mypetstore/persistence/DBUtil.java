package org.csu.mypetstore.persistence;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import javax.sql.DataSource;
import java.sql.*;

public class DBUtil {
    private static final DataSource datasource;

    static {
        datasource = new ComboPooledDataSource("otherc3p0");
    }

    //获取连接
    public static Connection getConnection() throws Exception {
        Connection connection = null;

        try {
            connection = datasource.getConnection();
        }catch (Exception e){
            throw e;
        }

        return connection;
    }

    public static void closeStatement(Statement statement) throws Exception {
        statement.close();
    }

    public static void closePreparedStatent(PreparedStatement pStatement) throws Exception{
        pStatement.close();
    }

    public static void closeResultSet(ResultSet resultSet) throws Exception{
        resultSet.close();
    }

    //关闭连接
    public static void closeConnection(Connection connection) throws Exception {
        connection.close();
    }

    /*
    //test the db connection
    public static void main(String[] args) throws Exception{
        Connection conn = DBUtil.getConnection();
        System.out.println("数据库连接成功");
    }
   */
}
